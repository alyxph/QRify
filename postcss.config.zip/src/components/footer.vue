<template>
  <footer class="bg-slate-50 text-slate-700 py-10">
    <div class="max-w-6xl mx-auto px-6 grid grid-cols-1 md:grid-cols-2 gap-6 items-center">
      <div class="flex items-center gap-4">
        <svg width="48" height="48" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" class="text-sky-600">
          <rect x="2" y="2" width="7" height="7" rx="1" fill="currentColor" />
          <rect x="15" y="2" width="7" height="7" rx="1" fill="currentColor" />
          <rect x="2" y="15" width="7" height="7" rx="1" fill="currentColor" />
        </svg>
        <div>
          <div class="font-bold text-lg">QRify</div>
          <div class="text-sm text-slate-500">Buat QR Code dengan cepat — sepenuhnya di browser Anda</div>
        </div>
      </div>

      <div class="flex flex-col items-end">
        <div class="text-sm font-medium text-slate-500 mb-1">Social</div>
        <div class="flex gap-4">
          <a href="https://github.com/alyxph" target="_blank" rel="noopener noreferrer" class="text-slate-600 hover:text-slate-800">
            <!-- GitHub -->
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="currentColor">
              <path d="M12 .297c-6.63 0-12 5.373-12 12 0 5.303 3.438 9.8 8.205 11.387.6.113.82-.258.82-.577 0-.285-.01-1.04-.015-2.04-3.338.724-4.042-1.61-4.042-1.61-.546-1.387-1.333-1.757-1.333-1.757-1.089-.744.084-.729.084-.729 1.205.084 1.84 1.236 1.84 1.236 1.07 1.835 2.809 1.305 3.495.998.108-.776.418-1.305.762-1.605-2.665-.303-5.467-1.334-5.467-5.93 0-1.31.469-2.381 1.236-3.221-.124-.303-.536-1.523.117-3.176 0 0 1.008-.322 3.301 1.23.96-.267 1.98-.399 3-.405 1.02.006 2.04.138 3 .405 2.291-1.552 3.297-1.23 3.297-1.23.655 1.653.243 2.873.12 3.176.77.84 1.235 1.911 1.235 3.221 0 4.61-2.807 5.625-5.48 5.922.43.372.823 1.102.823 2.222 0 1.606-.015 2.896-.015 3.293 0 .319.216.694.825.576C20.565 22.092 24 17.592 24 12.297c0-6.627-5.373-12-12-12"/></svg>
          </a>
          <a href="https://www.instagram.com/alief_rchmtl?igsh=Y3lxMjFjajZ4c3Vi&utm_source=qr" target="_blank" rel="noopener noreferrer" class="text-slate-600 hover:text-slate-800">
            <!-- Instagram -->
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
              <rect x="2" y="2" width="20" height="20" rx="5" ry="5"></rect>
              <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"></path>
              <line x1="17.5" y1="6.5" x2="17.5" y2="6.5"></line>
            </svg>
          </a>
          <a href="https://www.linkedin.com/in/alief-rachmattul-2a4602218/" target="_blank" rel="noopener noreferrer" class="text-slate-600 hover:text-slate-800">
            <!-- LinkedIn -->
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="currentColor">
              <path d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-10h3v10zm-1.5-11.268c-.966 0-1.75-.79-1.75-1.763s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.784 1.763-1.75 1.763zm13.5 11.268h-3v-5.604c0-1.337-.027-3.058-1.865-3.058-1.868 0-2.154 1.459-2.154 2.968v5.694h-3v-10h2.881v1.367h.041c.401-.76 1.379-1.561 2.84-1.561 3.038 0 3.602 2.001 3.602 4.599v5.595z"/>
            </svg>
          </a>
        </div>
      </div>
    </div>
  </footer>
</template>